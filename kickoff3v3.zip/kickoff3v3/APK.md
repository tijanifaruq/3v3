# Turning Kickoff 3v3 into an Android APK

The game is a web app, so an APK is a thin Android shell around it. You need a computer for this (any OS). Two routes:

## Route A: PWABuilder (no Android Studio)

Best if your server is already online over HTTPS (e.g. Render, Railway, Fly.io).

1. Deploy this folder (`node server.js`) to a host that supports WebSockets. Note its address, e.g. `https://kickoff.onrender.com`.
2. Open https://www.pwabuilder.com, paste that address, press Start.
3. Choose **Package for stores > Android**, keep the defaults (it already reads `manifest.webmanifest`, which asks for fullscreen landscape), and download.
4. The zip contains an `.apk` you can install directly (enable "install unknown apps") and an `.aab` for Google Play.

The app then opens your hosted game, so online play works with no extra setup, and Solo mode keeps working offline after the first launch.

## Route B: Capacitor + Android Studio (fully offline shell)

```
npm init -y
npm i @capacitor/core @capacitor/cli @capacitor/android three@0.128.0
mkdir -p public/vendor && cp node_modules/three/build/three.min.js public/vendor/
npx cap init "Kickoff 3v3" com.yourname.kickoff3v3 --web-dir public
npx cap add android
```

Then:
1. In `public/index.html` set `const DEFAULT_SERVER = 'wss://your-server-address';` (or leave it empty and type the address in the app's Settings).
2. In `android/app/src/main/AndroidManifest.xml`, on the `<activity>` tag add `android:screenOrientation="sensorLandscape"`.
   If your server is plain `ws://` (not `wss://`), also add `android:usesCleartextTraffic="true"` to the `<application>` tag.
3. `npx cap sync android && npx cap open android`
4. In Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is ready to install on any phone.

The 3D engine is bundled in `public/vendor/`, so Solo mode works with no internet at all.

## Notes

- Online matches always need your server running somewhere reachable from the phones. The APK does not contain the server.
- For Google Play you need a signed release build (Android Studio: Build > Generate Signed Bundle) and a developer account.
