/* ============================================================================
   game.js - shared 3v3 football simulation.
   The SAME file runs on the Node server (authoritative online matches) and in
   the browser (solo mode + local movement prediction for online play).

   World: x = pitch length (goals at x = +-HL), z = pitch width, y = up.
   Team 0 attacks +x, team 1 attacks -x. Player ids are slots 0..5:
   slots 0-2 = team 0, slots 3-5 = team 1.
   ========================================================================== */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.FootballGame = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const C = {
    HL: 15, HW: 9,            // half pitch length / width
    GH: 2.6, GOAL_H: 2.3, GD: 2.2,   // goal half-width, crossbar height, net depth
    BR: 0.33, PR: 0.55,       // ball / player radius
    RUN: 6.2, SPRINT: 9.0, ACC: 38, DEC: 52, TURN: 16,
    SPRINT_TIME: 2.8, STAM_REGEN: 5.0,
    LUNGE_T: 0.36, LUNGE_SPEED: 11.5, LUNGE_CD: 1.15,
    G: 20, FRIC: 0.75,
    MATCH_TIME: 180, COUNTDOWN: 3, KICKOFF_COUNTDOWN: 2, GOAL_TIME: 2.8,
    PICK_R: 1.15
  };
  const PH = { COUNTDOWN: 0, PLAYING: 1, GOAL: 2, FULLTIME: 3 };

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const angDiff = (a, b) => { let d = b - a; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return d; };
  const r2 = v => Math.round(v * 100) / 100;

  /* -------------------------------------------------------------------------
     Movement for ONE player. Also used by the client to predict the local
     player, so it only touches the player's own fields.
     ----------------------------------------------------------------------- */
  function movePlayer(p, mx, mz, sprint, dt) {
    let m = Math.hypot(mx, mz);
    if (m > 1) { mx /= m; mz /= m; m = 1; }
    if (m < 0.1) { mx = 0; mz = 0; m = 0; }
    if (p.lungeCd > 0) p.lungeCd -= dt;
    if (p.stun > 0) p.stun -= dt;

    if (p.exh && p.stam > 0.3) p.exh = false;
    let sprinting = !!sprint && m > 0.3 && !p.exh && p.lunge <= 0 && p.stam > 0;
    if (sprinting) {
      p.stam -= dt / C.SPRINT_TIME;
      if (p.stam <= 0) { p.stam = 0; p.exh = true; sprinting = false; }
    } else {
      p.stam = Math.min(1, p.stam + dt / C.STAM_REGEN);
    }
    p.sprinting = sprinting;

    if (p.lunge > 0) {
      p.lunge -= dt;
      const k = Math.min(1, Math.max(0, p.lunge) / C.LUNGE_T + 0.35);
      p.vx = p.lgx * C.LUNGE_SPEED * k;
      p.vz = p.lgz * C.LUNGE_SPEED * k;
    } else {
      let max = sprinting ? C.SPRINT : C.RUN;
      if (p.stun > 0) max *= 0.35;
      let dx = mx * max - p.vx, dz = mz * max - p.vz;
      const d = Math.hypot(dx, dz);
      const acc = (m > 0 ? C.ACC : C.DEC) * dt;
      if (d > acc) { dx = dx / d * acc; dz = dz / d * acc; }
      p.vx += dx; p.vz += dz;
    }

    p.x += p.vx * dt; p.z += p.vz * dt;
    const LX = C.HL - C.PR, LZ = C.HW - C.PR;
    if (p.x > LX) { p.x = LX; if (p.vx > 0) p.vx = 0; } else if (p.x < -LX) { p.x = -LX; if (p.vx < 0) p.vx = 0; }
    if (p.z > LZ) { p.z = LZ; if (p.vz > 0) p.vz = 0; } else if (p.z < -LZ) { p.z = -LZ; if (p.vz < 0) p.vz = 0; }

    if (p.lunge > 0) p.a = Math.atan2(p.lgz, p.lgx);
    else if (m > 0) {
      const da = angDiff(p.a, Math.atan2(mz, mx));
      const st = C.TURN * dt;
      p.a += clamp(da, -st, st);
    }
    if (p.a > Math.PI) p.a -= 2 * Math.PI; else if (p.a < -Math.PI) p.a += 2 * Math.PI;
  }

  function makePlayer(id) {
    return {
      id, team: id < 3 ? 0 : 1, slot: id % 3,
      x: 0, z: 0, vx: 0, vz: 0, a: id < 3 ? 0 : Math.PI,
      stam: 1, exh: false, sprinting: false,
      lunge: 0, lgx: 1, lgz: 0, lungeCd: 0, stun: 0, lock: 0,
      charge: 0, holding: false, lastPc: 0, lastSr: 0, lastTc: 0, synced: false, ack: 0, hit: false, lungeWas: 0,
      human: false, name: 'CPU', skill: 0.94,
      in: { mx: 0, mz: 0, sp: 0, sh: 0, pc: 0, sr: 0, tc: 0 },
      ai: { cool: 0, react: 0.3, shootT: 0, passTo: -1 }
    };
  }

  /* ========================================================================
     Game
     ====================================================================== */
  class Game {
    constructor(opts) {
      opts = opts || {};
      this.matchTime = opts.matchTime || C.MATCH_TIME;
      this.players = [0, 1, 2, 3, 4, 5].map(makePlayer);
      this.ball = { x: 0, y: C.BR, z: 0, vx: 0, vy: 0, vz: 0, owner: -1, lastTouch: -1, passTo: -1, passT: 0 };
      this.score = [0, 0];
      this.clock = this.matchTime;
      this.phase = PH.COUNTDOWN;
      this.phaseT = C.COUNTDOWN;
      this.time = 0; this.tick = 0;
      this.events = [];
      this.lastGoal = null;        // [team, scorerId]
      this.resetPositions(opts.kickTeam == null ? 0 : opts.kickTeam);
    }

    resetPositions(kickTeam) {
      this.kickTeam = kickTeam; this.grace = 0;
      const b = this.ball;
      b.x = 0; b.y = C.BR; b.z = 0; b.vx = b.vy = b.vz = 0; b.owner = -1; b.passTo = -1; b.passT = 0;
      const base = [[-8.5, 0], [-4.8, -3.6], [-4.8, 3.6]];
      for (const p of this.players) {
        let [x, z] = base[p.slot];
        if (p.team === kickTeam && p.slot === 2) { x = -1.5; z = 0; }
        if (p.team === 1) { x = -x; z = -z; }
        p.x = x; p.z = z; p.vx = p.vz = 0;
        p.a = p.team === 0 ? 0 : Math.PI;
        p.lunge = 0; p.lungeCd = 0; p.stun = 0; p.lock = 0; p.charge = 0; p.holding = false;
        p.stam = 1; p.exh = false; p.sprinting = false;
        p.ai.shootT = 0; p.ai.cool = 0.5; p.ai.passTo = -1; p.hit = false; p.lungeWas = 0;
      }
    }

    /* ------------------------------ main step ------------------------------ */
    step(dt) {
      this.time += dt; this.tick++;
      const ph = this.phase;

      if (ph === PH.COUNTDOWN) {
        this.phaseT -= dt;
        for (const p of this.players) { p.vx = p.vz = 0; p.sprinting = false; }
        if (this.phaseT <= 0) { this.phase = PH.PLAYING; this.phaseT = 0; this.grace = 0.9; this.events.push(['w']); }
        return;
      }
      if (ph === PH.GOAL) {
        this.phaseT -= dt;
        for (const p of this.players) { p.vx = p.vz = 0; p.sprinting = false; }
        this.stepBall(dt);
        if (this.phaseT <= 0) {
          const conceded = this.lastGoal ? 1 - this.lastGoal[0] : 0;
          this.resetPositions(conceded);
          this.phase = PH.COUNTDOWN; this.phaseT = C.KICKOFF_COUNTDOWN;
        }
        return;
      }
      if (ph === PH.FULLTIME) {
        for (const p of this.players) { p.vx = p.vz = 0; p.sprinting = false; }
        this.stepBall(dt);
        return;
      }

      // ---- PLAYING ----
      this.clock -= dt;
      if (this.grace > 0) this.grace -= dt;          // kickoff protection: the kicking team gets a moment before anyone presses
      const ps = this.players;
      const order = (this.tick & 1) ? [5, 4, 3, 2, 1, 0] : [0, 1, 2, 3, 4, 5];   // no team gets update priority

      for (const i of order) {
        const p = ps[i];
        if (p.lock > 0) p.lock -= dt;
        if (!p.human) botThink(this, p, dt);
        const inp = p.in;
        // tackle request (counter based so quick taps are never lost)
        if (inp.tc !== p.lastTc) { p.lastTc = inp.tc; this.tryLunge(p); }
        movePlayer(p, inp.mx, inp.mz, inp.sp, dt);
        if (p.lungeWas > 0 && p.lunge <= 0 && !p.hit) p.stun = Math.max(p.stun, 0.25);   // missed tackle: brief stumble
        p.lungeWas = p.lunge;
      }

      // player vs player separation
      for (let i = 0; i < 6; i++) for (let j = i + 1; j < 6; j++) {
        const a = ps[i], b = ps[j];
        let dx = b.x - a.x, dz = b.z - a.z;
        const d = Math.hypot(dx, dz), min = C.PR * 2;
        if (d < min && d > 1e-4) {
          const push = (min - d) * 0.5; dx /= d; dz /= d;
          a.x -= dx * push; a.z -= dz * push; b.x += dx * push; b.z += dz * push;
        }
      }

      // kicks
      for (const i of order) {
        const p = ps[i], inp = p.in;
        if (inp.sh) { p.charge = Math.min(1, p.charge + dt / 0.65); p.holding = true; }
        if (inp.sr !== p.lastSr) {
          p.lastSr = inp.sr;
          this.doShoot(p, Math.max(0.3, p.charge));
          p.charge = 0; p.holding = false;
        } else if (!inp.sh) { p.charge = 0; p.holding = false; }
        if (inp.pc !== p.lastPc) { p.lastPc = inp.pc; this.doPass(p); }
      }

      // tackles: the ball is only won FACE TO FACE. The tackler must be lunging at the carrier
      // and the carrier must be facing the tackler. From behind or the side it fails.
      {
        const bl = this.ball, ow = bl.owner >= 0 ? ps[bl.owner] : null;
        if (ow) for (const i of order) {
          const p = ps[i];
          if (p.lunge <= 0 || p.hit || p.team === ow.team) continue;
          const dx = ow.x - p.x, dz = ow.z - p.z, d = Math.hypot(dx, dz);
          if (d > 1.6 || d < 1e-4) continue;
          const nx = dx / d, nz = dz / d;
          const tackling = p.lgx * nx + p.lgz * nz;                     // tackler heading at the carrier
          const facing = -(Math.cos(ow.a) * nx + Math.sin(ow.a) * nz);  // carrier facing the tackler
          p.hit = true;
          if (tackling > 0.35 && facing > 0.3) {
            bl.owner = p.id; bl.lastTouch = p.id; bl.passTo = -1;
            ow.lock = 0.8; ow.stun = 0.5; p.lunge = 0; p.lock = 0; p.stun = 0;
            this.events.push(['t', p.id, ow.id]);
          } else {
            p.stun = 0.45; p.lunge = 0;                                  // beaten: nothing won
            this.events.push(['x', p.id]);
          }
          break;
        }
      }

      this.stepBall(dt);

      if (this.clock <= 0 && this.phase === PH.PLAYING) {
        this.clock = 0; this.phase = PH.FULLTIME; this.phaseT = 0;
        this.ball.owner = -1;
        this.events.push(['f']);
      }
    }

    /* ------------------------------ actions -------------------------------- */
    aimOf(p) {
      const m = Math.hypot(p.in.mx, p.in.mz);
      if (m > 0.3) return [p.in.mx / m, p.in.mz / m];
      return [Math.cos(p.a), Math.sin(p.a)];
    }
    canKick(p) {
      const b = this.ball;
      if (b.owner === p.id) return true;
      return b.owner < 0 && b.y < 1.0 && Math.hypot(b.x - p.x, b.z - p.z) < 1.45;
    }
    kick(p, dx, dz, speed, lift, power, passTo) {
      const b = this.ball, n = Math.hypot(dx, dz) || 1;
      dx /= n; dz /= n;
      b.owner = -1; b.lastTouch = p.id;
      b.passTo = passTo == null ? -1 : passTo; b.passT = b.passTo >= 0 ? 2.2 : 0;
      const off = C.PR + C.BR + 0.08;
      b.x = clamp(p.x + dx * off, -C.HL + C.BR, C.HL - C.BR);
      b.z = clamp(p.z + dz * off, -C.HW + C.BR, C.HW - C.BR);
      b.y = Math.max(b.y, C.BR);
      b.vx = dx * speed; b.vz = dz * speed; b.vy = lift;
      p.lock = 0.28; p.a = Math.atan2(dz, dx);
      this.events.push(['k', p.id, r2(power)]);
    }
    doShoot(p, power) {
      if (!this.canKick(p)) return;
      let [dx, dz] = this.aimOf(p);
      const att = p.team === 0 ? 1 : -1;
      const gx = att * C.HL;
      const toG = Math.atan2(-p.z, gx - p.x);
      const diff = Math.abs(angDiff(Math.atan2(dz, dx), toG));
      const dg = Math.hypot(gx - p.x, p.z);
      if (diff < 0.6 && dg < 19) {                       // arcade aim assist
        const side = p.z > 0.3 ? -1 : p.z < -0.3 ? 1 : (Math.random() < 0.5 ? -1 : 1);
        const tz = side * (C.GH - 0.9) * (0.45 + 0.55 * Math.random());
        const tx = gx - p.x, tzz = tz - p.z, tl = Math.hypot(tx, tzz) || 1;
        const w = (p.human ? 0.75 : 0.4) * (1 - diff / 0.6);
        dx = dx * (1 - w) + (tx / tl) * w; dz = dz * (1 - w) + (tzz / tl) * w;
      }
      if (!p.human) { const e = (Math.random() - 0.5) * 0.4; const c = Math.cos(e), s = Math.sin(e); [dx, dz] = [dx * c - dz * s, dx * s + dz * c]; }
      this.kick(p, dx, dz, (p.human ? 14 + 13 * power : 13 + 8 * power), 1.0 + 4.0 * power, power);
    }
    doPass(p) {
      if (!this.canKick(p)) return;
      const forced = p.ai.passTo; p.ai.passTo = -1;
      const [ax, az] = this.aimOf(p);
      const stick = Math.hypot(p.in.mx, p.in.mz) > 0.3;
      let best = forced >= 0 ? this.players[forced] : null;
      if (best && best.team !== p.team) best = null;
      if (!best) {
        let bs = -1e9;
        for (const t of this.players) {
          if (t.team !== p.team || t === p) continue;
          const vx = t.x - p.x, vz = t.z - p.z, d = Math.hypot(vx, vz);
          if (d < 1.2) continue;
          const dot = (vx * ax + vz * az) / d;
          if (dot < (stick ? 0.5 : 0)) continue;
          const s = dot * 2.5 - d * 0.04;
          if (s > bs) { bs = s; best = t; }
        }
        if (!best && !stick) {                                // no direction given: nearest teammate
          let nd = 1e9;
          for (const t of this.players) if (t.team === p.team && t !== p) { const d = Math.hypot(t.x - p.x, t.z - p.z); if (d < nd) { nd = d; best = t; } }
        }
      }
      if (!best) { this.kick(p, ax, az, 13, 0, 0.4, -1); return; }
      // aim at where the receiver will be when the ball arrives (ground friction aware)
      let tx = best.x, tz = best.z, d = Math.hypot(tx - p.x, tz - p.z);
      for (let i = 0; i < 3; i++) {
        const T = Math.min(1.2, d / clamp(10 + d * 0.7, 11, 19));
        tx = clamp(best.x + best.vx * T * 0.9, -C.HL + 1, C.HL - 1); tz = clamp(best.z + best.vz * T * 0.9, -C.HW + 1, C.HW - 1);
        d = Math.hypot(tx - p.x, tz - p.z);
      }
      const run = Math.max(1, d - 0.96), T = run / clamp(10 + run * 0.7, 11, 19);
      const v0 = clamp(run * C.FRIC / (1 - Math.exp(-C.FRIC * T)), 9, 26);
      this.kick(p, tx - p.x, tz - p.z, v0, 0, 0.4, best.id);
    }
    tryLunge(p) {
      if (p.lungeCd > 0 || p.lunge > 0 || p.stun > 0) return;
      if (this.grace > 0 && p.team !== this.kickTeam) return;
      if (this.ball.owner === p.id) return;                  // can't slide with the ball
      let [dx, dz] = this.aimOf(p);
      // aim assist: toward the ball carrier (or loose ball) in front of us
      const b = this.ball;
      const tgt = b.owner >= 0 && this.players[b.owner].team !== p.team ? this.players[b.owner] : (b.owner < 0 ? b : null);
      if (tgt) {
        const vx = tgt.x - p.x, vz = tgt.z - p.z, d = Math.hypot(vx, vz);
        if (d < 3 && d > 0.01 && (vx * dx + vz * dz) / d > 0.55) { dx = vx / d; dz = vz / d; }
      }
      p.lunge = C.LUNGE_T; p.lungeCd = C.LUNGE_CD; p.lgx = dx; p.lgz = dz; p.hit = false; p.lungeWas = C.LUNGE_T;
      this.events.push(['l', p.id]);
    }

    /* ------------------------------ ball ----------------------------------- */
    stepBall(dt) {
      const b = this.ball, ps = this.players;

      if (b.owner >= 0) {
        const p = ps[b.owner];
        const dist = Math.hypot(b.x - p.x, b.z - p.z);
        if (this.phase !== PH.PLAYING || dist > 2.0 || p.lunge > 0) {
          b.owner = -1;
        } else {
          const wob = p.sprinting ? 0.35 * (0.5 + 0.5 * Math.sin(this.time * 11 + p.id)) : 0.08;
          const off = C.PR + C.BR + 0.12 + wob;
          const tx = clamp(p.x + Math.cos(p.a) * off, -C.HL + C.BR + 0.3, C.HL - C.BR - 0.3);
          const tz = clamp(p.z + Math.sin(p.a) * off, -C.HW + C.BR, C.HW - C.BR);
          const k = Math.min(1, 16 * dt);
          b.x += (tx - b.x) * k; b.z += (tz - b.z) * k;
          b.vx = p.vx; b.vz = p.vz; b.y = C.BR; b.vy = 0;
          return;
        }
      }

      // free ball physics
      if (b.passT > 0) { b.passT -= dt; if (b.passT <= 0) b.passTo = -1; }
      b.vy -= C.G * dt; b.y += b.vy * dt;
      if (b.y < C.BR) {
        b.y = C.BR;
        if (b.vy < -1.8) b.vy = -b.vy * 0.5; else b.vy = 0;
      }
      if (b.y <= C.BR + 0.02) { const f = Math.exp(-C.FRIC * dt); b.vx *= f; b.vz *= f; }
      else { const f = Math.exp(-0.1 * dt); b.vx *= f; b.vz *= f; }
      b.x += b.vx * dt; b.z += b.vz * dt;

      const ax = Math.abs(b.x), sx = b.x < 0 ? -1 : 1;
      if (ax > C.HL) {
        // inside the goal (only reachable through the mouth): net clamps
        if (ax > C.HL + C.GD - C.BR) { b.x = sx * (C.HL + C.GD - C.BR); b.vx *= -0.2; }
        if (Math.abs(b.z) > C.GH - C.BR) { b.z = (b.z < 0 ? -1 : 1) * (C.GH - C.BR); b.vz *= -0.3; }
        if (b.y > C.GOAL_H - C.BR) { b.y = C.GOAL_H - C.BR; b.vy = -Math.abs(b.vy) * 0.3; }
        if (this.phase === PH.PLAYING) this.scoreGoal(sx === 1 ? 0 : 1);
      } else if (ax > C.HL - C.BR) {
        const open = Math.abs(b.z) < C.GH - 0.15 && b.y < C.GOAL_H - 0.15;
        if (!open) { b.x = sx * (C.HL - C.BR); if (b.vx * sx > 0) b.vx *= -0.65; }
      }
      if (Math.abs(b.x) <= C.HL) {
        if (b.z > C.HW - C.BR) { b.z = C.HW - C.BR; if (b.vz > 0) b.vz *= -0.7; }
        else if (b.z < -C.HW + C.BR) { b.z = -C.HW + C.BR; if (b.vz < 0) b.vz *= -0.7; }
      }

      if (this.phase !== PH.PLAYING) return;

      // pick up / deflect
      const hspd = Math.hypot(b.vx, b.vz);
      let best = -1, bd = 1e9;
      for (const p of (this.tick & 1 ? ps.slice().reverse() : ps)) {
        const d = Math.hypot(p.x - b.x, p.z - b.z);
        if (p.lock <= 0 && !(this.grace > 0 && p.team !== this.kickTeam)) {
          const rcv = p.id === b.passTo, big = p.lunge > 0 || rcv;
          const R = big ? 1.7 : C.PICK_R, vmax = big ? 24 : 15, de = rcv ? d * 0.6 : d;   // intended receiver wins ties
          if (d < R && b.y < 0.95 && hspd < vmax && de < bd) { bd = de; best = p.id; }
        }
      }
      if (best >= 0) { b.owner = best; b.lastTouch = best; b.passTo = -1; return; }
      for (const p of ps) {                                   // body blocks the ball
        const d = Math.hypot(b.x - p.x, b.z - p.z), min = C.PR + C.BR;
        if (d < min && d > 1e-4 && b.y < 1.4) {
          const nx = (b.x - p.x) / d, nz = (b.z - p.z) / d;
          b.x = p.x + nx * min; b.z = p.z + nz * min;
          const vn = b.vx * nx + b.vz * nz;
          if (vn < 0) { b.vx -= 1.5 * vn * nx; b.vz -= 1.5 * vn * nz; }
          b.vx += p.vx * 0.4; b.vz += p.vz * 0.4;
          b.lastTouch = p.id;
        }
      }
    }

    scoreGoal(team) {
      this.score[team]++;
      const scorer = this.ball.lastTouch >= 0 && this.players[this.ball.lastTouch].team === team ? this.ball.lastTouch : -1;
      this.lastGoal = [team, scorer];
      this.phase = PH.GOAL; this.phaseT = C.GOAL_TIME;
      this.ball.owner = -1;
      this.events.push(['g', team, scorer]);
    }

    /* ---------------------------- network view ----------------------------- */
    flags(p) {
      return (p.sprinting ? 1 : 0) | (p.lunge > 0 ? 2 : 0) | (p.stun > 0 ? 4 : 0) |
        (p.charge > 0.05 ? 8 : 0) | (this.ball.owner === p.id ? 16 : 0) | (p.exh ? 32 : 0) | (p.human ? 64 : 0);
    }
    snapshot() {
      const b = this.ball;
      return {
        t: 's', k: this.tick, st: r2(this.time), ph: this.phase, pt: r2(this.phaseT), cl: r2(this.clock),
        sc: this.score, lg: this.lastGoal,
        b: [r2(b.x), r2(b.y), r2(b.z), r2(b.vx), r2(b.vy), r2(b.vz), b.owner],
        p: this.players.map(p => [r2(p.x), r2(p.z), r2(p.a), r2(p.vx), r2(p.vz), r2(p.stam), this.flags(p), r2(Math.max(0, p.lunge)), r2(Math.max(0, p.stun))]),
        ak: this.players.map(p => p.ack),
        ev: this.events.splice(0)
      };
    }
  }

  /* ========================================================================
     Bot AI. Fills p.in exactly like a human's input would.
     ====================================================================== */
  function steer(p, inp, tx, tz, arrive, sprint) {
    const dx = tx - p.x, dz = tz - p.z, d = Math.hypot(dx, dz);
    if (d < 0.2) { inp.mx = 0; inp.mz = 0; inp.sp = 0; return d; }
    const s = Math.min(1, d / arrive) * p.skill;
    inp.mx = dx / d * s; inp.mz = dz / d * s;
    inp.sp = sprint && p.stam > 0.25 ? 1 : 0;
    return d;
  }

  function botThink(g, p, dt) {
    const ai = p.ai, inp = p.in, b = g.ball, ps = g.players;
    const att = p.team === 0 ? 1 : -1, gx = att * C.HL, ownGx = -gx;
    ai.cool = Math.max(0, ai.cool - dt); ai.react = Math.max(0, ai.react - dt);
    const owner = b.owner >= 0 ? ps[b.owner] : null;
    const has = owner === p;
    const teamHas = !!owner && owner.team === p.team;
    const oppHas = !!owner && owner.team !== p.team;
    inp.sp = 0;
    if (b.owner !== p.id) ai.had = false;

    if (ai.shootT > 0) {                                  // holding a shot
      ai.shootT -= dt; inp.sh = 1;
      steer(p, inp, gx, clamp(p.z * 0.5, -1.5, 1.5), 1, false);
      if (ai.shootT <= 0) { inp.sh = 0; inp.sr++; }
      return;
    }
    inp.sh = 0;

    // who is the best chaser on my team? (goalkeeper-ish slot 0 only chases near its own goal)
    const tx0 = owner ? owner.x : b.x + b.vx * 0.2, tz0 = owner ? owner.z : b.z + b.vz * 0.2;
    let chaser = null, cd = 1e9;
    for (const t of ps) {
      if (t.team !== p.team) continue;
      let d = Math.hypot(t.x - tx0, t.z - tz0);
      if (t.slot === 0 && b.x * att > -2) d += 100;
      if (d < cd) { cd = d; chaser = t; }
    }

    // an incoming pass: the intended receiver goes to meet it, everyone else holds shape
    if (!owner && b.passTo >= 0 && ps[b.passTo].team === p.team) {
      if (b.passTo === p.id) { steer(p, inp, b.x + b.vx * 0.35, b.z + b.vz * 0.35, 0.6, true); return; }
      chaser = ps[b.passTo];
    }

    if (has) {
      const dgoal = Math.abs(gx - p.x);
      let opp = null, od = 1e9;
      for (const o of ps) if (o.team !== p.team) { const d = Math.hypot(o.x - p.x, o.z - p.z); if (d < od) { od = d; opp = o; } }
      if (p.slot !== 0 && dgoal < 10 && ai.cool <= 0 && (dgoal < 6.5 || Math.random() < 0.12 * dt * 60)) {
        ai.shootT = 0.2 + Math.random() * 0.35; ai.cool = 0.9;
        return;
      }
      ai.hold = has && ai.had ? ai.hold - dt : 0.5; ai.had = true;
      if (ai.cool <= 0 && (ai.hold <= 0 || od < 1.3) && (p.slot === 0 && od < 4 && p.x * att < -4 || od < 2.2 && Math.random() < 0.7)) {
        let mate = null, ms = -1e9;
        for (const t of ps) {
          if (t.team !== p.team || t === p) continue;
          let free = 1e9;
          for (const o of ps) if (o.team !== p.team) free = Math.min(free, Math.hypot(o.x - t.x, o.z - t.z));
          const adv = (t.x - p.x) * att;
          if (adv < -1 && od > 1.2) continue;                  // no pointless back-passes unless pinned
          const s = Math.min(free, 6) + adv * 0.35;
          if (s > ms) { ms = s; mate = t; }
        }
        if (mate) {
          const dx = mate.x - p.x, dz = mate.z - p.z, d = Math.hypot(dx, dz) || 1;
          inp.mx = dx / d; inp.mz = dz / d; ai.passTo = mate.id; inp.pc++; ai.cool = 0.7;
          return;
        }
      }
      let tz = p.z;
      if (opp && od < 4 && (opp.x - p.x) * att > 0) tz = p.z + (p.z > opp.z ? 3.5 : -3.5);
      else tz = p.z * 0.6;
      steer(p, inp, gx, clamp(tz, -C.HW + 1.2, C.HW - 1.2), 1.2, dgoal > 7);
      return;
    }

    if (oppHas && chaser === p) {
      const dx = owner.x - p.x, dz = owner.z - p.z, dd = Math.hypot(dx, dz) || 1, nx = dx / dd, nz = dz / dd;
      const facing = -(Math.cos(owner.a) * nx + Math.sin(owner.a) * nz);      // is the carrier facing me?
      let tx = owner.x + owner.vx * 0.25, tz = owner.z + owner.vz * 0.25;
      if (facing < 0.3 && dd < 7) { tx = owner.x + Math.cos(owner.a) * 2.4; tz = owner.z + Math.sin(owner.a) * 2.4; }   // cut in front
      steer(p, inp, tx, tz, 1.2, true);
      if (dd > 2.6 || facing < 0.3) ai.react = 0.2 + Math.random() * 0.25;
      else if (dd < 1.9 && ai.react <= 0 && p.lungeCd <= 0) { inp.mx = nx; inp.mz = nz; inp.tc++; ai.react = 0.4 + Math.random() * 0.3; }
      return;
    }

    if (!owner && chaser === p) {
      const bx = b.x + b.vx * 0.25, bz = b.z + b.vz * 0.25;
      const d = steer(p, inp, bx, bz, 0.8, true);
      if (p.slot === 0 && d < 3.4 && p.lungeCd <= 0 && Math.hypot(b.vx, b.vz) > 5 && (b.vx * ownGx > 0)) {
        inp.tc++;                                         // keeper dive
      }
      return;
    }

    // positioning
    const bx = b.x * att;
    let tx, tz;
    if (p.slot === 0) {
      // keeper-style: stand on the line from the ball to our goal centre, closer to goal when the ball is near
      const dball = Math.abs(b.x - ownGx), stand = clamp(1.6 + dball * 0.18, 1.6, 5);
      tx = ownGx + att * stand;
      tz = clamp(b.z * (stand / Math.max(stand, dball)) * 1.4, -C.GH + 0.3, C.GH - 0.3);
    } else if (p.slot === 1) {
      tx = att * clamp(bx + (teamHas ? 3 : -4), -10, 10);
      tz = clamp(-b.z * 0.45 - 3, -7, 7);
    } else {
      tx = att * clamp(teamHas ? bx + 5 : bx * 0.5 + 1, -4, 12.5);
      tz = clamp(-b.z * 0.4 + 3, -7, 7);
    }
    const d = Math.hypot(tx - p.x, tz - p.z);
    steer(p, inp, tx, tz, 1.5, d > 6);
  }

  return { C, PH, Game, movePlayer, makePlayer, angDiff };
});
