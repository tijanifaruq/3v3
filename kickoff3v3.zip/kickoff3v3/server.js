'use strict';
/* ============================================================================
   Kickoff 3v3 - authoritative multiplayer server (no npm dependencies).
   - Serves the client from /public
   - Minimal RFC 6455 WebSocket implementation
   - Lobby: quick match, private rooms with 4-letter code, team switching
   - One Game per room at 60 Hz, 30 Hz snapshots. Clients only send input;
     the server owns ball, positions, goals, clock and bots.
   - Disconnected humans are replaced by bots instantly and can reclaim their
     footballer (same browser token) or be replaced by a new joiner.
   ========================================================================== */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const FG = require('./public/game.js');

const PORT = parseInt(process.env.PORT, 10) || 3000;
const MATCH_SECONDS = parseFloat(process.env.MATCH_SECONDS) || FG.C.MATCH_TIME;
const FULLTIME_HOLD = parseFloat(process.env.FULLTIME_HOLD) || 9;
const PUB = path.join(__dirname, 'public');
const MAX_ROOMS = 400, MAX_CLIENTS = 3000;
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css',
  '.json': 'application/json', '.png': 'image/png', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.ico': 'image/x-icon'
};

/* ------------------------------ static files ------------------------------ */
const server = http.createServer((req, res) => {
  let url;
  try { url = decodeURIComponent((req.url || '/').split('?')[0]); } catch (e) { res.writeHead(400); return res.end(); }
  if (url === '/healthz') { res.writeHead(200); return res.end('ok'); }
  if (url === '/' || url === '') url = '/index.html';
  const file = path.normalize(path.join(PUB, url));
  if (file !== PUB && !file.startsWith(PUB + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
});

/* --------------------------- tiny WebSocket layer --------------------------- */
function frame(op, payload) {
  const len = payload.length;
  let head;
  if (len < 126) head = Buffer.from([0x80 | op, len]);
  else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | op; head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x80 | op; head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([head, payload]);
}
const textFrame = obj => frame(1, Buffer.from(typeof obj === 'string' ? obj : JSON.stringify(obj)));

class Conn {
  constructor(socket) {
    this.socket = socket; this.buf = Buffer.alloc(0); this.frags = []; this.alive = true;
    this.onmessage = null; this.onclose = null;
    socket.on('data', d => this.onData(d));
    socket.on('close', () => this.kill());
    socket.on('error', () => this.kill());
  }
  onData(chunk) {
    this.buf = this.buf.length ? Buffer.concat([this.buf, chunk]) : chunk;
    while (this.alive && this.buf.length >= 2) {
      const b0 = this.buf[0], b1 = this.buf[1];
      const fin = !!(b0 & 0x80), op = b0 & 0x0f, masked = !!(b1 & 0x80);
      let len = b1 & 0x7f, off = 2;
      if (len === 126) { if (this.buf.length < 4) return; len = this.buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (this.buf.length < 10) return; len = Number(this.buf.readBigUInt64BE(2)); off = 10; }
      if (len > 8192 || !masked) return this.close();
      if (this.buf.length < off + 4 + len) return;
      const mask = this.buf.subarray(off, off + 4);
      const payload = Buffer.from(this.buf.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < len; i++) payload[i] ^= mask[i & 3];
      this.buf = this.buf.subarray(off + 4 + len);
      if (op === 8) return this.close();
      if (op === 9) { this.write(frame(10, payload)); continue; }
      if (op === 10) continue;
      if (op === 1 || op === 0) {
        this.frags.push(payload);
        if (fin) {
          const msg = Buffer.concat(this.frags).toString('utf8'); this.frags = [];
          if (this.onmessage) this.onmessage(msg);
        } else if (this.frags.length > 8) return this.close();
      }
    }
  }
  write(buf) {
    if (!this.alive) return;
    if (this.socket.writableLength > 96 * 1024) return;      // slow client: drop instead of queueing
    this.socket.write(buf);
  }
  send(obj) { this.write(textFrame(obj)); }
  close() { if (!this.alive) return; try { this.socket.write(frame(8, Buffer.alloc(0))); } catch (e) { } this.kill(); try { this.socket.end(); } catch (e) { } }
  kill() { if (!this.alive) return; this.alive = false; if (this.onclose) this.onclose(); }
}

server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if (!key || String(req.headers.upgrade).toLowerCase() !== 'websocket' || clients.size >= MAX_CLIENTS) { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);
  socket.setTimeout(0);
  onConnect(new Conn(socket));
});

/* --------------------------------- rooms ----------------------------------- */
const clients = new Set();
const rooms = new Map();           // code -> Room
const tokens = new Map();          // token -> { room, slot }   (reconnect support)
let nextId = 1;

const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
function newCode() {
  for (let n = 0; n < 200; n++) {
    let c = '';
    for (let i = 0; i < 4; i++) c += CODE_CHARS[crypto.randomInt(CODE_CHARS.length)];
    if (!rooms.has(c)) return c;
  }
  return null;
}
const cleanName = s => String(s || '').replace(/[^\p{L}\p{N} _\-.!]/gu, '').trim().slice(0, 12);

class Room {
  constructor(code, pub) {
    this.code = code; this.pub = pub; this.state = 'lobby';
    this.slots = [0, 1, 2, 3, 4, 5].map(() => ({ client: null, name: '', reclaim: null, reclaimAt: 0 }));
    this.host = null; this.game = null; this.acc = 0; this.snapTick = 0;
    this.autoAt = 0; this.fullAt = 0; this.emptySince = Date.now();
  }
  humans() { return this.slots.filter(s => s.client).length; }
  teamCount(t) { return this.slots.slice(t * 3, t * 3 + 3).filter(s => s.client).length; }
  freeSlot(team) {
    for (let i = team * 3; i < team * 3 + 3; i++) {
      const s = this.slots[i];
      if (!s.client && !(s.reclaim && Date.now() < s.reclaimAt)) return i;
    }
    for (let i = team * 3; i < team * 3 + 3; i++) if (!this.slots[i].client) return i;   // steal a reserved slot if no other room
    return -1;
  }
  canJoin() {
    if (this.state === 'lobby') return this.humans() < 6;
    return this.slots.some(s => !s.client) && this.game && this.game.clock > 25 && this.game.phase !== FG.PH.FULLTIME;
  }
  add(client, preferTeam) {
    let order = preferTeam != null ? [preferTeam, 1 - preferTeam] : (this.teamCount(0) <= this.teamCount(1) ? [0, 1] : [1, 0]);
    for (const t of order) {
      const i = this.freeSlot(t);
      if (i >= 0) { this.attach(client, i); return true; }
    }
    return false;
  }
  attach(client, i) {
    const s = this.slots[i];
    s.client = client; s.name = client.name; s.reclaim = null;
    client.room = this; client.slot = i;
    tokens.set(client.token, { room: this, slot: i });
    if (!this.host) this.host = client;
    this.emptySince = 0;
    if (this.game) {
      const p = this.game.players[i];
      p.human = true; p.name = client.name; p.synced = false; p.ack = 0;
      p.in.mx = p.in.mz = p.in.sp = p.in.sh = 0;
      p.ai.shootT = 0;
    }
  }
  detach(client, voluntary) {
    const i = client.slot;
    if (i < 0 || this.slots[i].client !== client) return;
    const s = this.slots[i];
    s.client = null;
    if (!voluntary && this.state === 'playing') { s.reclaim = client.token; s.reclaimAt = Date.now() + 90000; }
    else { s.reclaim = null; tokens.delete(client.token); s.name = ''; }
    client.room = null; client.slot = -1;
    if (this.game) {
      const p = this.game.players[i];
      p.human = false; p.name = 'CPU'; p.synced = false;
      p.in.mx = p.in.mz = 0; p.in.sp = 0; p.in.sh = 0;     // bot takes over right away
      p.in.pc = p.lastPc; p.in.tc = p.lastTc; p.in.sr = p.lastSr;
      p.ai.shootT = 0; p.ai.cool = 0.5; p.ai.passTo = -1;
    }
    if (this.host === client) this.host = (this.slots.find(x => x.client) || {}).client || null;
    if (!this.humans()) this.emptySince = Date.now();
    this.broadcastRoom();
  }
  roomMsg() {
    const auto = this.state === 'lobby' && this.autoAt ? Math.max(0, Math.ceil((this.autoAt - Date.now()) / 1000)) : null;
    return {
      t: 'room', code: this.code, pub: this.pub, state: this.state, host: this.host ? this.host.id : 0, auto,
      slots: this.slots.map((s, i) => ({ id: s.client ? s.client.id : 0, name: s.client ? s.client.name : (this.game ? 'CPU' : ''), bot: !s.client, team: i < 3 ? 0 : 1 }))
    };
  }
  broadcastRoom() {
    const m = this.roomMsg();
    for (const s of this.slots) if (s.client) s.client.send(m);
    this.updateAuto();
  }
  updateAuto() {            // public rooms start by themselves once enough people are in
    if (this.state !== 'lobby' || !this.pub) { this.autoAt = 0; return; }
    const n = this.humans();
    if (n >= 6) { if (!this.autoAt || this.autoAt - Date.now() > 3000) this.autoAt = Date.now() + 3000; }
    else if (n >= 2) { if (!this.autoAt) this.autoAt = Date.now() + 12000; }
    else this.autoAt = 0;
  }
  start() {
    if (this.state !== 'lobby') return;
    this.state = 'playing'; this.autoAt = 0;
    const g = this.game = new FG.Game({ matchTime: MATCH_SECONDS, kickTeam: Math.random() < 0.5 ? 0 : 1 });
    this.acc = 0; this.snapTick = 0; this.fullAt = 0;
    this.slots.forEach((s, i) => {
      const p = g.players[i];
      p.human = !!s.client; p.name = s.client ? s.client.name : 'CPU'; p.synced = false;
      p.skill = 0.94;
    });
    this.broadcastRoom();
    for (const s of this.slots) if (s.client) this.sendStart(s.client);
  }
  sendStart(client) {
    client.send({ t: 'start', you: client.slot, mt: this.game.matchTime });
    client.send(this.roomMsg());
  }
  returnToLobby() {
    this.state = 'lobby'; this.game = null; this.fullAt = 0;
    for (const s of this.slots) { if (!s.client) { s.reclaim = null; s.name = ''; } }
    for (const [tk, v] of tokens) if (v.room === this && !this.slots[v.slot].client) tokens.delete(tk);
    this.autoAt = 0;
    this.broadcastRoom();
  }
  update(dt) {
    const g = this.game;
    if (this.state === 'lobby') {
      if (this.autoAt && Date.now() >= this.autoAt) this.start();
      return;
    }
    if (!g) return;
    this.acc += dt;
    let guard = 0;
    while (this.acc >= 1 / 60 && guard++ < 6) {
      g.step(1 / 60); this.acc -= 1 / 60;
      if (++this.snapTick % 2 === 0) this.sendSnapshot();
    }
    if (this.acc > 0.2) this.acc = 0;
    if (g.phase === FG.PH.FULLTIME) {
      if (!this.fullAt) this.fullAt = Date.now() + FULLTIME_HOLD * 1000;
      else if (Date.now() >= this.fullAt) this.returnToLobby();
    }
  }
  sendSnapshot() {
    const buf = textFrame(this.game.snapshot());
    for (const s of this.slots) if (s.client) s.client.write(buf);
  }
}

/* ------------------------------- clients ----------------------------------- */
function onConnect(conn) {
  const client = {
    conn, id: nextId++, name: 'Player', token: '', room: null, slot: -1, msgs: 0, tick: Date.now(),
    send: m => conn.send(m), write: b => conn.write(b)
  };
  clients.add(client);
  conn.onmessage = raw => {
    const now = Date.now();
    if (now - client.tick > 1000) { client.tick = now; client.msgs = 0; }
    if (++client.msgs > 140) return;                       // flood guard (input is ~30/s)
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (m && typeof m.t === 'string' && (client.token || m.t === 'hello')) handle(client, m);
  };
  conn.onclose = () => {
    clients.delete(client);
    if (client.room) client.room.detach(client, false);
  };
}

const num = (v, lo, hi) => { v = +v; return v === v ? Math.max(lo, Math.min(hi, v)) : 0; };

function handle(c, m) {
  switch (m.t) {
    case 'hello': {
      c.name = cleanName(m.name) || 'Player' + (c.id % 1000);
      c.token = String(m.token || '').replace(/[^\w-]/g, '').slice(0, 40) || crypto.randomBytes(8).toString('hex');
      // reconnect to a running match?
      const r = tokens.get(c.token);
      let resumed = false;
      if (r && r.room && rooms.get(r.room.code) === r.room && r.room.state === 'playing') {
        const s = r.room.slots[r.slot];
        if (!s.client && s.reclaim === c.token) { r.room.attach(c, r.slot); resumed = true; }
      }
      c.send({ t: 'welcome', id: c.id, resume: resumed });
      if (resumed) { c.room.broadcastRoom(); c.room.sendStart(c); }
      break;
    }
    case 'ping': c.send({ t: 'pong', ts: m.ts }); break;
    case 'quick': {
      if (c.room) return;
      let best = null;
      for (const r of rooms.values()) {
        if (!r.pub || !r.canJoin()) continue;
        const sc = (r.state === 'lobby' ? 100 : 0) + r.humans();
        if (!best || sc > best.sc) best = { r, sc };
      }
      let room = best && best.r;
      if (!room) room = makeRoom(true);
      if (!room) return c.send({ t: 'err', msg: 'Server is full, try again soon.' });
      room.add(c);
      room.broadcastRoom();
      if (room.state === 'playing') room.sendStart(c);
      break;
    }
    case 'create': {
      if (c.room) return;
      const room = makeRoom(false);
      if (!room) return c.send({ t: 'err', msg: 'Server is full, try again soon.' });
      room.add(c); room.broadcastRoom();
      break;
    }
    case 'join': {
      if (c.room) return;
      const room = rooms.get(String(m.code || '').toUpperCase().trim());
      if (!room) return c.send({ t: 'err', msg: 'No room with that code.' });
      if (!room.canJoin()) return c.send({ t: 'err', msg: room.state === 'lobby' ? 'That room is full.' : 'That match is full or about to end.' });
      room.add(c); room.broadcastRoom();
      if (room.state === 'playing') room.sendStart(c);
      break;
    }
    case 'team': {
      const r = c.room; if (!r || r.state !== 'lobby') return;
      const to = c.slot < 3 ? 1 : 0, i = r.freeSlot(to);
      if (i < 0) return c.send({ t: 'err', msg: 'That team is full.' });
      r.slots[c.slot].client = null; r.slots[c.slot].name = '';
      r.attach(c, i); r.broadcastRoom();
      break;
    }
    case 'start': {
      const r = c.room;
      if (r && r.state === 'lobby' && r.host === c) r.start();
      break;
    }
    case 'leave': {
      const r = c.room;
      if (r) { r.detach(c, true); }
      break;
    }
    case 'in': {
      const r = c.room;
      if (!r || !r.game || r.state !== 'playing') return;
      const p = r.game.players[c.slot];
      if (!p.human) return;
      const i = p.in;
      i.mx = num(m.mx, -1, 1); i.mz = num(m.mz, -1, 1);
      i.sp = m.sp ? 1 : 0; i.sh = m.sh ? 1 : 0;
      const pc = m.pc | 0, sr = m.sr | 0, tc = m.tc | 0;
      if (!p.synced) { p.lastPc = pc; p.lastSr = sr; p.lastTc = tc; p.synced = true; }
      i.pc = pc; i.sr = sr; i.tc = tc;
      p.ack = m.s | 0;
      break;
    }
  }
}

function makeRoom(pub) {
  if (rooms.size >= MAX_ROOMS) return null;
  const code = newCode(); if (!code) return null;
  const r = new Room(code, pub);
  rooms.set(code, r);
  return r;
}

/* ------------------------------- main loop --------------------------------- */
let last = process.hrtime.bigint();
setInterval(() => {
  const now = process.hrtime.bigint();
  const dt = Math.min(0.1, Number(now - last) / 1e9); last = now;
  for (const r of rooms.values()) r.update(dt);
}, 1000 / 60);

setInterval(() => {                      // housekeeping
  const now = Date.now();
  for (const [code, r] of rooms) {
    if (r.state === 'lobby' && r.autoAt) r.broadcastRoom();      // keeps the auto-start countdown fresh
    if (!r.humans() && r.emptySince && now - r.emptySince > 20000) {
      rooms.delete(code);
      for (const [tk, v] of tokens) if (v.room === r) tokens.delete(tk);
    }
  }
}, 1000);

server.listen(PORT, '0.0.0.0', () => {
  console.log('Kickoff 3v3 server on http://0.0.0.0:' + PORT + '  (match length ' + MATCH_SECONDS + 's)');
});
module.exports = { server, rooms };
