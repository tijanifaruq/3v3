'use strict';
/* Runs the real client script (public/index.html) in Node with a stubbed DOM + three.js,
   then plays a solo match and an online match against the real server. Catches runtime errors in
   UI flow, input mapping, prediction/reconciliation and interpolation. (Does not render pixels.) */
const fs = require('fs'), vm = require('vm'), path = require('path'), { spawn } = require('child_process');
const PORT = 3056;
const html = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8');
const code = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)][1][1];

function stub() {
  const f = function () { };
  return new Proxy(f, {
    get(t, k) { if (k === Symbol.toPrimitive) return () => 0; if (k === 'then') return undefined; if (k === 'length') return 0; return stub(); },
    set() { return true }, apply() { return stub(); }, construct() { return stub(); }
  });
}
const els = {};
function el(id) {
  const o = { id, value: '', textContent: '', style: { setProperty() { } }, children: [], _cls: new Set(),
    classList: { add(c) { o._cls.add(c) }, remove(c) { o._cls.delete(c) }, contains(c) { return o._cls.has(c) }, toggle(c, on) { (on === undefined ? !o._cls.has(c) : on) ? o._cls.add(c) : o._cls.delete(c) } },
    addEventListener(t, fn) { (o.ev[t] = o.ev[t] || []).push(fn) }, ev: {}, appendChild(c) { o.children.push(c) }, append() { }, setPointerCapture() { }, offsetWidth: 0 };
  return new Proxy(o, { get(t, k) { if (k in t) return t[k]; return stub(); }, set(t, k, v) { t[k] = v; if (k === 'textContent') t.children = []; return true; } });
}
const doc = {
  getElementById(id) { return els[id] || (els[id] = el(id)); }, createElement() { return el('x'); },
  addEventListener() { }, documentElement: el('root'), head: { appendChild() { } }, fullscreenElement: null
};
const win = {}; const listeners = {};
let rafCb = null;
const THREE = stub();
const g = {
  window: win, document: doc, THREE, FootballGame: require('../public/game.js'), innerWidth: 800, innerHeight: 400, devicePixelRatio: 2,
  addEventListener(t, fn) { (listeners[t] = listeners[t] || []).push(fn) },
  requestAnimationFrame(cb) { rafCb = cb; return 1 }, localStorage: { getItem() { return null }, setItem() { } },
  location: { protocol: 'http:', host: '127.0.0.1:' + PORT, search: '', origin: 'http://127.0.0.1:' + PORT },
  navigator: { vibrate() { }, share: null }, screen: {}, WebSocket, performance, setTimeout, clearTimeout, setInterval, console,
  URLSearchParams, Float32Array, Math, JSON, Promise, Object, Array, Set, Proxy, Symbol, Date
};
Object.assign(g, { self: g });
vm.createContext(g);
vm.runInContext(code, g);
const fire = (t, e) => (listeners[t] || []).forEach(fn => fn(Object.assign({ preventDefault() { }, repeat: false }, e)));
let uncaught = 0;
process.on('uncaughtException', e => { uncaught++; console.error('UNCAUGHT', e); });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let fails = 0; const ok = (c, m) => { console.log((c ? '  ok   ' : '  FAIL ') + m); if (!c) fails++; };

(async () => {
  win.__start();
  ok(typeof rafCb === 'function', 'client booted and scheduled its frame loop');
  const drive = async (ms, dtms = 16) => { const t0 = performance.now(); while (performance.now() - t0 < ms) { rafCb(performance.now()); await sleep(dtms); } };

  console.log('SOLO');
  els.btnSolo.onclick();
  await drive(200);
  ok(!els.hud._cls.has('hidden') && els.menu._cls.has('hidden'), 'HUD shown, menu hidden');
  // fast-forward by feeding big fake times (frames are dt-capped at 50ms): run ~12 s of game
  let t = performance.now();
  fire('keydown', { code: 'KeyD' });
  for (let i = 0; i < 12 * 20; i++) { t += 50; rafCb(t); }
  fire('keyup', { code: 'KeyD' });
  ok(els.clock.textContent !== '3:00', 'match clock is running (' + els.clock.textContent + ')');
  els.bPass.ev.pointerdown[0]({ preventDefault() { }, pointerId: 1 });
  els.bShoot.ev.pointerdown[0]({ preventDefault() { }, pointerId: 2 });
  for (let i = 0; i < 20; i++) { t += 50; rafCb(t); }
  els.bShoot.ev.pointerup[0]({});
  for (let i = 0; i < 40; i++) { t += 50; rafCb(t); }
  ok(true, 'pass / shoot / sprint / tackle button handlers ran');
  for (let i = 0; i < 60 * 20 * 6; i++) { t += 50; rafCb(t); if (!els.full._cls.has('hidden')) break; }
  ok(!els.full._cls.has('hidden'), 'full-time screen appears (' + els.fA.textContent + '-' + els.fB.textContent + ', ' + els.fRes.textContent + ')');
  els.btnQuit.onclick(); // leave
  ok(true, 'leave ok');
  els.fBtns.children[1] && els.fBtns.children[1].onclick && els.fBtns.children[1].onclick();

  console.log('ONLINE (real server)');
  const srv = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env: Object.assign({}, process.env, { PORT, MATCH_SECONDS: '30', FULLTIME_HOLD: '2' }), stdio: ['ignore', 'ignore', 'inherit'] });
  await sleep(600);
  // an independent raw observer joins the same room so we can verify the server really sees our client's inputs
  els.nameIn.value = 'Tester';
  els.btnCreate.onclick();
  await drive(800);
  ok(!els.lobby._cls.has('hidden'), 'lobby screen shown');
  const code4 = els.lobCode.textContent;
  ok(/^[A-Z]{4}$/.test(code4), 'room code displayed: ' + code4);
  const obs = new WebSocket('ws://127.0.0.1:' + PORT); const snaps = []; let obsStart = null;
  obs.onmessage = e => { const m = JSON.parse(e.data); if (m.t === 's') snaps.push(m); if (m.t === 'start') obsStart = m; };
  await new Promise(r => obs.onopen = r); obs.send(JSON.stringify({ t: 'hello', name: 'Observer', token: 'obs1' })); await sleep(100);
  obs.send(JSON.stringify({ t: 'join', code: code4 })); await drive(300);
  ok(els.team0.children.length + els.team1.children.length === 6, 'lobby lists 6 slots');
  els.btnStart.onclick();
  await drive(600);
  ok(els.lobby._cls.has('hidden') && !els.hud._cls.has('hidden'), 'both switched to match screen');
  await drive(3600);                         // countdown
  const my = snaps[snaps.length - 1];
  fire('keydown', { code: 'KeyW' }); fire('keydown', { code: 'ShiftLeft' });
  const before = snaps[snaps.length - 1].p.map(p => p[0]);
  await drive(1500);
  fire('keyup', { code: 'KeyW' }); fire('keyup', { code: 'ShiftLeft' });
  const after = snaps[snaps.length - 1].p.map(p => p[0]);
  // the host (slot of the tester) is whichever slot has the human flag but is not the observer
  const humans = [0, 1, 2, 3, 4, 5].filter(i => snaps[snaps.length - 1].p[i][6] & 64);
  const meIdx = humans.find(i => i !== obsStart.you), dir = meIdx < 3 ? 1 : -1;
  ok(humans.length === 2, 'server sees 2 real humans (slots ' + humans + ')');
  ok((after[meIdx] - before[meIdx]) * dir > 3, 'tester held "up" -> server moved their footballer ' + ((after[meIdx] - before[meIdx]) * dir).toFixed(1) + ' m toward the opponent goal');
  ok(els.clock.textContent !== '0:30' && els.net.textContent !== undefined, 'online HUD updating (clock ' + els.clock.textContent + ', ' + els.net.textContent + ')');
  fire('keydown', { code: 'Space' }); await drive(300); fire('keyup', { code: 'Space' });
  fire('keydown', { code: 'KeyQ' }); await drive(500);
  ok(true, 'shoot/tackle online ran without error');
  console.log('  disconnect observer -> bot takeover, tester keeps playing');
  obs.close(); await drive(600);
  ok(true, 'still running after teammate/opponent left');
  let sawFull = false;
  for (let i = 0; i < 120 && els.lobby._cls.has('hidden'); i++) { await drive(1000); if (!els.full._cls.has('hidden')) sawFull = true; }
  ok(sawFull, 'full-time screen shown online (' + els.fA.textContent + '-' + els.fB.textContent + ')');
  ok(!els.lobby._cls.has('hidden'), 'returned to lobby after full time');
  els.btnLeave.onclick(); await drive(200);
  ok(!els.menu._cls.has('hidden'), 'back at the main menu');
  ok(uncaught === 0, 'no uncaught exceptions anywhere');
  srv.kill(); console.log(fails ? '\n' + fails + ' FAILED' : '\nCLIENT HARNESS PASSED'); process.exit(fails ? 1 : 0);
})().catch(e => { console.error('HARNESS ERROR', e); process.exit(1); });
