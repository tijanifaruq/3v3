'use strict';
/* Numerical check of the client prediction + reconciliation used in index.html under network latency. */
const FG = require('../public/game.js');
function run(oneWayMs, jitterMs) {
  const g = new FG.Game(); g.phase = FG.PH.PLAYING; g.phaseT = 0;
  const me = 1, sp = g.players[me]; sp.human = true;
  const pred = FG.makePlayer(me); Object.assign(pred, { x: sp.x, z: sp.z, a: sp.a });
  let corr = { x: 0, z: 0 }, hist = [], seq = 0, sendT = 0, predOn = true;
  const toServer = [], toClient = [];
  let t = 0, maxCorr = 0, sumCorr = 0, n = 0, maxVis = 0;
  const dt = 1 / 60;
  const jit = () => (Math.random() * 2 - 1) * jitterMs;
  for (let f = 0; f < 60 * 20; f++) {
    t += dt;
    // scripted stick: change direction every 1.5s, sprint half the time
    const ang = Math.floor(t / 1.5) * 1.3, mx = Math.cos(ang), mz = Math.sin(ang), spr = Math.floor(t / 3) % 2;
    sendT += dt;
    if (sendT >= 1 / 33) { sendT = 0; seq++; toServer.push({ at: t + (oneWayMs + jit()) / 1000, s: seq, mx, mz, sp: spr }); }
    if (predOn) { FG.movePlayer(pred, mx, mz, spr, dt); hist.push({ seq, dt, mx, mz, sp: spr }); }
    corr.x *= Math.exp(-10 * dt); corr.z *= Math.exp(-10 * dt);
    // server
    toServer.sort((a, b) => a.at - b.at);
    while (toServer.length && toServer[0].at <= t) { const m = toServer.shift(); Object.assign(sp.in, { mx: m.mx, mz: m.mz, sp: m.sp }); sp.ack = m.s; }
    g.step(dt);
    if (g.tick % 2 === 0) toClient.push({ at: t + (oneWayMs + jit()) / 1000, p: [sp.x, sp.z, sp.a, sp.vx, sp.vz, sp.stam, 0, 0, 0], ak: sp.ack, ph: g.phase });
    toClient.sort((a, b) => a.at - b.at);
    while (toClient.length && toClient[0].at <= t) {
      const m = toClient.shift(), d = m.p;
      const ox = pred.x + corr.x, oz = pred.z + corr.z, was = predOn; predOn = m.ph === FG.PH.PLAYING;
      pred.x = d[0]; pred.z = d[1]; pred.a = d[2]; pred.vx = d[3]; pred.vz = d[4]; pred.stam = d[5]; pred.exh = sp.exh; pred.lunge = 0; pred.stun = 0;
      hist = hist.filter(h => h.seq > m.ak);
      if (predOn) for (const h of hist) FG.movePlayer(pred, h.mx, h.mz, h.sp, h.dt);
      let ex = ox - pred.x, ez = oz - pred.z; if (!was || !predOn) { ex = ez = 0; }
      const e = Math.hypot(ex, ez);
      corr.x = ex; corr.z = ez; maxCorr = Math.max(maxCorr, e); sumCorr += e; n++;
    }
    // how far ahead of the server (in position) is what the player sees? (should be ~speed*latency, i.e. responsive)
    if (predOn && g.phase === FG.PH.PLAYING) maxVis = Math.max(maxVis, Math.hypot(pred.x - sp.x, pred.z - sp.z));
  }
  return { rtt: oneWayMs * 2, jitter: jitterMs, avgCorr: (sumCorr / n).toFixed(3), maxCorr: maxCorr.toFixed(2), aheadOfServer: maxVis.toFixed(2) };
}
for (const [l, j] of [[20, 0], [40, 10], [80, 25], [150, 40]]) console.log(JSON.stringify(run(l, j)));
if (process.env.DEBUG) { console.log(JSON.stringify(run(0, 0))); console.log(JSON.stringify(run(1, 0))); }
