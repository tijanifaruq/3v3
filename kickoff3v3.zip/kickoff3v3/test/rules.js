'use strict';
/* Gameplay rule tests: face-to-face tackles, and pass accuracy (bots <-> human). */
const FG = require('../public/game.js'); const { Game, PH } = FG;
let fails = 0; const ok = (c, m) => { console.log((c ? '  ok   ' : '  FAIL ') + m); if (!c) fails++; };
function setup() { const g = new Game(); g.phase = PH.PLAYING; g.phaseT = 0; for (const p of g.players) { p.human = true; p.x = 100; p.z = 100; } return g; }  // park everyone far away
function park(g) { g.players.forEach((p, i) => { p.x = 12 + i * 0.01; p.z = -8 + i * 0.1; p.vx = p.vz = 0; }); }

console.log('tackles');
for (const [name, tx, tz, tdir, cdir, want] of [
  ['tackled face to face (carrier faces tackler)', 2, 0, Math.PI, 0, true],
  ['tackled from BEHIND (carrier faces away)', -2, 0, 0, 0, false],
  ['tackled from the SIDE', 0, 2, -Math.PI / 2, 0, false],
]) {
  const g = setup(); park(g);
  const c = g.players[3], t = g.players[0];            // carrier is team 1, tackler team 0
  c.x = 0; c.z = 0; c.a = cdir === 0 && name.includes('face to face') ? 0 : 0; t.x = tx; t.z = tz; t.a = tdir;
  c.a = 0;                                              // carrier faces +x
  g.ball.owner = c.id; g.ball.x = 1; g.ball.z = 0;
  g.step(1 / 60);
  t.in.mx = Math.cos(tdir); t.in.mz = Math.sin(tdir); t.in.tc++;
  for (let i = 0; i < 40; i++) g.step(1 / 60);
  const stolen = g.ball.owner === t.id;
  ok(stolen === want, name + ' -> ' + (stolen ? 'tackler got the ball' : 'carrier kept it'));
}
{ // no steal without a tackle: opponent standing next to the carrier (even behind) can't take it
  const g = setup(); park(g); const c = g.players[3], o = g.players[0];
  c.x = 0; c.z = 0; c.a = 0; o.x = -1.0; o.z = 0; g.ball.owner = c.id;
  for (let i = 0; i < 120; i++) g.step(1 / 60);
  ok(g.ball.owner === c.id, 'opponent touching the carrier from behind cannot take the ball');
}

console.log('passes');
function passTest(fromId, toId, n, noOpp) {
  let done = 0;
  for (let k = 0; k < n; k++) {
    const g = new Game(); g.phase = PH.PLAYING; g.phaseT = 0;
    g.players.forEach(p => { p.human = false; });       // bots everywhere, then make the passer scripted
    const from = g.players[fromId]; from.human = true;
    if (noOpp) for (const o of g.players) if (o.team !== from.team) { o.human = true; o.x = 14; o.z = 8; o.in.mx = o.in.mz = 0; }
    for (let i = 0; i < 40; i++) g.step(1 / 60);
    // give the passer the ball at a random spot, mates in normal AI motion
    from.x = (Math.random() - 0.5) * 16; from.z = (Math.random() - 0.5) * 10; from.a = Math.random() * 6.28;
    g.phase = PH.PLAYING; g.phaseT = 0; g.ball.vx = g.ball.vz = 0; g.ball.owner = from.id; g.ball.x = from.x; g.ball.z = from.z;
    const mate = g.players[toId];
    const dx = mate.x - from.x, dz = mate.z - from.z, d = Math.hypot(dx, dz);
    if (d < 3 || d > 16) { k--; continue; }
    from.in.mx = dx / d; from.in.mz = dz / d; from.in.pc++;
    let got = -2;
    for (let i = 0; i < 180; i++) { g.step(1 / 60); if (g.ball.owner >= 0 && g.ball.owner !== from.id) { got = g.ball.owner; break; } }
    if (got === toId) done++;
  }
  return done / n;
}
// own team passes (opponents are idle-ish bots that may intercept, so we only require a high rate)
const hb = passTest(1, 2, 150, true), hb2 = passTest(1, 0, 150, true), live = passTest(1, 2, 150, false);
ok(hb > 0.9 && hb2 > 0.9, 'human passes to bot teammate arrive (no defenders): ' + Math.round(hb * 100) + '% (slot1->2), ' + Math.round(hb2 * 100) + '% (slot1->0)');
ok(live > 0.55, 'with live defenders still pressing: ' + Math.round(live * 100) + '% reach the teammate (rest are intercepted)');
// bot -> human: let bots play with a "human" that stands still-ish; count bot passes aimed at the human that complete
let aimed = 0, completed = 0;
for (let m = 0; m < 6; m++) {
  const g = new Game(); g.phase = PH.PLAYING; g.phaseT = 0; const h = g.players[1]; h.human = true;
  let pend = -1, prev = -1;
  for (let i = 0; i < 60 * 60; i++) {
    h.in.mx = Math.sin(i / 90); h.in.mz = Math.cos(i / 70) * 0.6;   // wanders like a person would
    g.step(1 / 60);
    for (const e of g.events) if (e[0] === 'k' && e[1] !== 1 && g.ball.passTo === 1) { aimed++; pend = 1; }
    g.events.length = 0;
    if (pend >= 0 && g.ball.owner >= 0) { if (g.ball.owner === 1) completed++; pend = -1; }
    if (g.phase === PH.GOAL) { g.phaseT = 0; }
    if (g.phase === PH.FULLTIME) break;
  }
}
ok(aimed > 5 && completed / aimed > 0.6, 'bot passes aimed at the human: ' + completed + '/' + aimed + ' reached him');
console.log(fails ? fails + ' FAILED' : 'RULES PASSED'); process.exit(fails ? 1 : 0);
