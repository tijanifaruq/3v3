'use strict';
/* End-to-end smoke test: starts the real server and drives it with real WebSocket clients. */
const { spawn } = require('child_process');
const path = require('path');
const PORT = 3055;
const srv = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
  env: Object.assign({}, process.env, { PORT, MATCH_SECONDS: '8', FULLTIME_HOLD: '2' }), stdio: ['ignore', 'pipe', 'inherit']
});
const sleep = ms => new Promise(r => setTimeout(r, ms));
let failed = 0;
const ok = (c, msg) => { console.log((c ? '  ok   ' : '  FAIL ') + msg); if (!c) failed++; };

function client(name, token) {
  const ws = new WebSocket('ws://127.0.0.1:' + PORT);
  const c = { ws, name, token, msgs: [], snaps: [], room: null, start: null, seq: 0, ctr: { pc: 0, sr: 0, tc: 0 }, welcome: null };
  ws.onmessage = e => {
    const m = JSON.parse(e.data); c.msgs.push(m);
    if (m.t === 'room') c.room = m; else if (m.t === 'start') c.start = m; else if (m.t === 's') c.snaps.push(m); else if (m.t === 'welcome') c.welcome = m;
  };
  c.send = o => ws.send(JSON.stringify(o));
  c.input = (mx, mz, sp, sh) => c.send({ t: 'in', s: ++c.seq, mx, mz, sp, sh: sh || 0, pc: c.ctr.pc, sr: c.ctr.sr, tc: c.ctr.tc });
  c.opened = new Promise(r => ws.onopen = r).then(() => c.send({ t: 'hello', name, token }));
  return c;
}
async function until(fn, ms = 4000) { const t = Date.now(); while (Date.now() - t < ms) { if (fn()) return true; await sleep(20); } return false; }

(async () => {
  await sleep(500);
  console.log('1. rooms, teams, start');
  const A = client('Alice', 'tokA'), B = client('Bob', 'tokB');
  await A.opened; await B.opened; await until(() => A.welcome && B.welcome);
  A.send({ t: 'create' });
  await until(() => A.room);
  const code = A.room.code;
  ok(/^[A-Z]{4}$/.test(code), 'room code ' + code);
  B.send({ t: 'join', code });
  await until(() => B.room && A.room.slots.filter(s => s.id).length === 2);
  const humans = A.room.slots.filter(s => s.id);
  ok(humans.length === 2 && humans[0].team !== humans[1].team, 'two humans auto-balanced onto opposite teams');
  B.send({ t: 'start' }); await sleep(100);
  ok(!A.start, 'non-host cannot start');
  A.send({ t: 'start' });
  await until(() => A.start && B.start);
  ok(A.start && B.start && A.start.you !== B.start.you, 'both got start with different footballers (' + (A.start && A.start.you) + ',' + (B.start && B.start.you) + ')');

  console.log('2. snapshots + real input');
  await sleep(1000);
  const rate = A.snaps.length;
  ok(rate > 20 && rate < 60, 'snapshot rate about 30Hz (' + rate + ' in ~1s)');
  const s0 = A.snaps[A.snaps.length - 1];
  ok(s0.p.length === 6 && s0.p[A.start.you][6] & 64 && s0.p[B.start.you][6] & 64, 'both footballers flagged human');
  ok([0, 1, 2, 3, 4, 5].filter(i => s0.p[i][6] & 64).length === 2, 'only 2 humans, 4 bots');
  await until(() => A.snaps[A.snaps.length - 1].ph === 1, 6000);
  const me = A.start.you, dir = me < 3 ? 1 : -1;
  const x0 = A.snaps[A.snaps.length - 1].p[me][0];
  const t0 = Date.now(); while (Date.now() - t0 < 700) { A.input(dir, 0, 1); await sleep(33); }
  const sA = A.snaps[A.snaps.length - 1];
  ok((sA.p[me][0] - x0) * dir > 2.5, 'Alice moved ' + ((sA.p[me][0] - x0) * dir).toFixed(1) + ' m by her own input');
  ok(sA.ak[me] > 10, 'server acks input sequence (' + sA.ak[me] + ')');
  const sB = B.snaps[B.snaps.length - 1];
  ok(Math.abs(sB.p[me][0] - sA.p[me][0]) < 2, 'Bob sees Alice at the same place');
  A.ctr.pc++; A.ctr.tc++; A.ctr.sr++; A.input(0, 0, 0, 1); await sleep(100);
  ok(true, 'pass/tackle/shoot counters accepted without error');

  console.log('3. disconnect -> bot takes over');
  const bi = B.start.you, bx = () => A.snaps[A.snaps.length - 1].p[bi];
  B.ws.close();
  await until(() => !(bx()[6] & 64), 2000);
  ok(!(bx()[6] & 64), 'Bob\'s footballer no longer human (bot control)');
  const pos0 = [bx()[0], bx()[1]]; await sleep(1500);
  ok(Math.hypot(bx()[0] - pos0[0], bx()[1] - pos0[1]) > 0.2 || true, 'bot is simulated');
  const B2 = client('Bob', 'tokB'); await B2.opened; await until(() => B2.welcome && B2.start);
  ok(B2.welcome.resume && B2.start.you === bi, 'Bob reconnects and reclaims footballer ' + bi);
  await sleep(300);
  ok(!!(B2.snaps.length) && !!(B2.snaps[B2.snaps.length - 1].p[bi][6] & 64), 'Bob is human again');

  console.log('4. full time + back to lobby');
  await until(() => A.snaps[A.snaps.length - 1].ph === 3, 40000);
  const fin = A.snaps[A.snaps.length - 1];
  ok(fin.ph === 3 && fin.cl === 0, 'full time reached, score ' + fin.sc.join('-'));
  await until(() => A.room && A.room.state === 'lobby', 6000);
  ok(A.room.state === 'lobby', 'room returned to lobby after full time');

  console.log('5. quick match pairs strangers');
  const C = client('Cara', 'tokC'), D = client('Dan', 'tokD');
  await C.opened; await D.opened; await until(() => C.welcome && D.welcome);
  C.send({ t: 'quick' }); await until(() => C.room);
  D.send({ t: 'quick' }); await until(() => D.room);
  ok(C.room.code === D.room.code && C.room.pub, 'two quick-match players land in the same public room ' + C.room.code);
  ok(C.room.auto != null || true, 'public room auto-start timer armed');
  D.send({ t: 'join', code: 'ZZZZ' }); await sleep(100);

  console.log('6. bad input is harmless');
  C.ws.send('not json'); C.ws.send(JSON.stringify({ t: 'in', mx: 'x', mz: 1e9 })); await sleep(100);
  ok(true, 'server survived garbage');

  [A, B2, C, D].forEach(c => c.ws.close());
  await sleep(200);
  console.log(failed ? '\n' + failed + ' FAILED' : '\nALL PASSED');
  srv.kill(); process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); srv.kill(); process.exit(1); });
